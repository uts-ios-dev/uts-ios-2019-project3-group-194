//
//  GameSettingView.swift
//  WerewolfGame
//
//  Created by 刘子铭 on 2019/6/2.
//  Copyright © 2019 King. All rights reserved.
//

import UIKit

class GameSettingViewController: UIViewController
{
    var seerQuantity = 0
    var witchQuantity = 0
    var saviorQuantity = 0
    var hunterQuantity = 0
    var idiotQuantity = 0
    var villagerQuantity = 0
    var werewolfQuantity = 0
    var forbidderQuantity = 0
    var roleList:[String] = []
    
    @IBOutlet weak var seerMinusBtn: UIButton!
    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var seerPlusBtn: UIButton!
    @IBOutlet weak var seerLabel: UILabel!
    @IBOutlet weak var witchMinusBtn: UIButton!
    @IBOutlet weak var witchPlusBtn: UIButton!
    @IBOutlet weak var witchLabel: UILabel!
    @IBOutlet weak var saviorMinusBtn: UIButton!
    @IBOutlet weak var saviorPlusBtn: UIButton!
    @IBOutlet weak var saviorLabel: UILabel!
    @IBOutlet weak var hunterMinusBtn: UIButton!
    @IBOutlet weak var hunterPlusBtn: UIButton!
    @IBOutlet weak var hunterLabel: UILabel!
    @IBOutlet weak var idiotMinusBtn: UIButton!
    @IBOutlet weak var idiotPlusBtn: UIButton!
    @IBOutlet weak var idiotLabel: UILabel!
    @IBOutlet weak var villagerMinusBtn: UIButton!
    @IBOutlet weak var villagerPlusBtn: UIButton!
    @IBOutlet weak var villagerLabel: UILabel!
    @IBOutlet weak var werewolfMinusBtn: UIButton!
    @IBOutlet weak var werewolfPlusBtn: UIButton!
    @IBOutlet weak var werewolfLabel: UILabel!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
 
    @IBAction func nextButtonClicked(_ sender: Any)
    {
        UserDefaults.standard.set(roleList, forKey: "roleList")
        print(roleList)
        self.performSegue(withIdentifier: "toCardView", sender: nil)
    }
    
    @IBAction func seerMinusBtnClicked(_ sender: Any)
    {
        if seerQuantity > 0
        {
            seerQuantity -= 1
            var index = 0
            var deleted = false
            for role in roleList
            {
                if role == "seer" && deleted == false
                {
                    roleList.remove(at: index)
                    deleted = true
                }
                index += 1
            }
        }
        seerLabel.text = String(seerQuantity)
    }
    
    @IBAction func seerPlusBtnClicked(_ sender: Any)
    {
        if seerQuantity < 1
        {
            seerQuantity += 1
            roleList.append("seer")
        }
        seerLabel.text = String(seerQuantity)
    }
    @IBAction func witchMinusBtnClicked(_ sender: Any)
    {
        if witchQuantity > 0
        {
            witchQuantity -= 1
            var index = 0
            var deleted = false
            for role in roleList
            {
                if role == "witch" && deleted == false
                {
                    roleList.remove(at: index)
                    deleted = true
                }
                index += 1
            }
        }
        witchLabel.text = String(witchQuantity)
    }
    
    @IBAction func witchPlusBtnClicked(_ sender: Any)
    {
        if witchQuantity < 1
        {
            witchQuantity += 1
            roleList.append("witch")
        }
        witchLabel.text = String(witchQuantity)
    }
    @IBAction func saviorMinusBtnClicked(_ sender: Any)
    {
        if saviorQuantity > 0
        {
            saviorQuantity -= 1
            var index = 0
            var deleted = false
            for role in roleList
            {
                if role == "savior" && deleted == false
                {
                    roleList.remove(at: index)
                    deleted = true
                }
                index += 1
            }
        }
        saviorLabel.text = String(saviorQuantity)
    }
    
    @IBAction func saviorPlusBtnClicked(_ sender: Any)
    {
        if saviorQuantity < 1
        {
            saviorQuantity += 1
            roleList.append("savior")
        }
        saviorLabel.text = String(saviorQuantity)
    }
    @IBAction func hunterMinusBtnClicked(_ sender: Any)
    {
        if hunterQuantity > 0
        {
            hunterQuantity -= 1
            var index = 0
            var deleted = false
            for role in roleList
            {
                if role == "hunter" && deleted == false
                {
                    roleList.remove(at: index)
                    deleted = true
                }
                index += 1
            }
        }
        hunterLabel.text = String(hunterQuantity)
    }
    
    @IBAction func hunterPlusBtnClicked(_ sender: Any)
    {
        if hunterQuantity < 1
        {
            hunterQuantity += 1
            roleList.append("hunter")
        }
        hunterLabel.text = String(hunterQuantity)
    }
    @IBAction func idiotMinusBtnClicked(_ sender: Any)
    {
        if idiotQuantity > 0
        {
            idiotQuantity -= 1
            var index = 0
            var deleted = false
            for role in roleList
            {
                if role == "idiot" && deleted == false
                {
                    roleList.remove(at: index)
                    deleted = true
                }
                index += 1
            }
        }
        idiotLabel.text = String(idiotQuantity)
    }
    
    @IBAction func idiotPlusBtnClicked(_ sender: Any)
    {
        if idiotQuantity < 1
        {
            idiotQuantity += 1
            roleList.append("idiot")
        }
        idiotLabel.text = String(idiotQuantity)
    }
    @IBAction func villagerMinusBtnClicked(_ sender: Any)
    {
        if villagerQuantity > 0
        {
            villagerQuantity -= 1
            var index = 0
            var deleted = false
            for role in roleList
            {
                if role == "villager" && deleted == false
                {
                    roleList.remove(at: index)
                    deleted = true
                }
                index += 1
            }
        }
        villagerLabel.text = String(villagerQuantity)
    }
    
    @IBAction func villagerPlusBtnClicked(_ sender: Any)
    {
        if villagerQuantity < 8
        {
            villagerQuantity += 1
            roleList.append("villager")
        }
        villagerLabel.text = String(villagerQuantity)
    }
    @IBAction func werewolfMinusBtnClicked(_ sender: Any)
    {
        if werewolfQuantity > 0
        {
            werewolfQuantity -= 1
            var index = 0
            var deleted = false
            for role in roleList
            {
                if role == "werewolf" && deleted == false
                {
                    roleList.remove(at: index)
                    deleted = true
                }
                index += 1
            }
        }
        werewolfLabel.text = String(werewolfQuantity)
    }
    
    @IBAction func werewolfPlusBtnClicked(_ sender: Any)
    {
        if werewolfQuantity < 8
        {
            werewolfQuantity += 1
            roleList.append("werewolf")
        }
        werewolfLabel.text = String(werewolfQuantity)
    }
}
