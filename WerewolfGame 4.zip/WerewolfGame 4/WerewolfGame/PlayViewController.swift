//
//  File.swift
//  WerewolfGame
//
//  Created by Anzi Wu on 5/6/19.
//  Copyright © 2019 King. All rights reserved.
//

import Foundation
import UIKit

class PlayViewController : UIViewController
{
    
    @IBOutlet weak var roles: UILabel!
    @IBOutlet weak var Time: UILabel!
    @IBOutlet weak var timerButton: UIButton!
    @IBOutlet weak var BackgroundImage: UIImageView!
    
    let dayImage = UIImage(named: "Day.png")
    let nightImage = UIImage(named: "Night.png")
    
    
    var seconds = 2
    var timerer:Timer!
    var i:Int = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        roles.text = "Close your eyes \nWerewolves, open your eyes \nWerewolves, pick someone to kill \nWerewolves, close your eyes"
        
    }
    
    func startCardDisplayTimer()
    {
        timerer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updatetime), userInfo: nil, repeats: true)
    }
    
    @objc func updatetime(){
        Time.text = String(timeFormatted(seconds));//"\timeFormatted(seconds)"
        if seconds != 0
        {
            seconds -= 1
        }
        else
        {
            //sender.setTitle("Start", for: .normal)
            timerer.invalidate()
            if i == 5
            {
                ///Change to Day
                BackgroundImage.image=dayImage
                timerButton.setTitle("Back to Night", for: .normal)
                print("i1:  ",i)
                i = -1
                print("i2:  ",i)
                seconds = 0
            }
            else
            {
                timerButton.setTitle("Start", for: .normal)
                seconds = 2
            }
            roles.text = changeRoles(round: i)
            isPuse = false
            print("i3:  ",i)
            i += 1
            
        }
    }
    
    func timeFormatted(_ totalseconds: Int) -> String{
        let seconds: Int = totalseconds % 60
        let minutes: Int = (totalseconds / 60) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    
    var isPuse: Bool = false
    
    @IBAction func StartTime(_ sender: UIButton)
    {
        if BackgroundImage.image != nightImage
        {
            BackgroundImage.image=nightImage
        }
        
        if isPuse == false
        {
            startCardDisplayTimer()
            sender.setTitle("Puse", for: .normal)
            isPuse = true
        }
        else
        {
            timerer.invalidate()
            sender.setTitle("Resume", for: .normal)
            isPuse = false
        }
    }

    func changeRoles(round:Int) -> String
    {
        
        switch round
        {
            case 0:
                return "Close your eyes \nWerewolves, open your eyes \nWerewolves, pick someone to kill \nWerewolves, close your eyes"
            case 1:
                return "Seer open your eyes \nSeer pick someone to ask about \n Seer close your eyes"
            case 2:
                return "Witch open your eyes \nYou have a antidote tonight this player die would you want to save this player \nYou have a poision \nWhich player you want to kill \nClose your eyes"
            case 3:
                return "Hunt open your eyes \nYou want to shoot or not \nClose your eyes"
            case 4:
                return "Savior open yours  eyes \nWhich one you want to protect \nClose your eyes"
            
            case 5:
                return ""
            default:
                return ""
        }
        return ""
    }
    
    @IBAction func NoteButton(_ sender: UIButton) {
    }
    
}
