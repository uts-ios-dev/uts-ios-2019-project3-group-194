//
//  CardViewController.swift
//  WerewolfGame
//
//  Created by 刘子铭 on 2019/5/22.
//  Copyright © 2019 King. All rights reserved.
//

import UIKit

class CardViewController: UIViewController
{
    
    let backgroundImageView = UIImageView()
    var isOpen = false
    
    @IBOutlet weak var roleName: UILabel!
    @IBOutlet weak var roleDetail: UITextView!
    @IBOutlet weak var card: UIButton!
    @IBOutlet weak var countNumLabel: UILabel!
    @IBOutlet weak var nextPlayerBtn: UIButton!
    
    
    var flipAnimationDuration = 0.1
    var durationTimer: Timer!
    var cardDisplayTimer: Timer!
    var cardDisplayTime = 7
    let transition = CATransition()
    var stopFlip = false
    var allCardsDealed = false
    var nextPlayer = false
    
    let image = UIImage(named: "cardBack")
    let roleList =  UserDefaults.standard.stringArray(forKey: "roleList") ?? [String]()
    
    var dynamicRoleList =  UserDefaults.standard.stringArray(forKey: "roleList") ?? [String]()
    
    var playerNum = 1
    

    override func viewDidLoad()
    {
        roleDetail.delegate = self as? UITextViewDelegate
        /////////////////
        print("display roleList")
        print(roleList)
        nextPlayerBtn.isHidden = true
        roleName.text = "Player 1"
        super.viewDidLoad()
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    
    func changePlayer()
    {
        playerNum += 1
        roleName.text = "Player " + String(playerNum)
        roleDetail.text = ""
    }

    @IBAction func flipCard(_ sender: Any)
    {

        if stopFlip == false
        {
            startDuratuonTimer()
            flipOnce()
        }
        else
        {
            if nextPlayer
            {
                resetDutrationTimer()
                flipOnce()
                nextPlayer = false
            }
            else if dynamicRoleList.count == 0
            {
                self.performSegue(withIdentifier: "toPlayView", sender: nil)
            }
        }
    }
    
    @IBAction func nextPlayerBtnAction(_ sender: Any)
    {
        countNumLabel.text = ""
        cardDisplayTime = 7
        stopCardDisplayTimer()
        goNextPlayer()
    }
    
    func goNextPlayer()
    {
        changePlayer()
        nextPlayer = true
        nextPlayerBtn.isHidden = true
        let image = UIImage(named: "cardBack")
        card.setImage(image, for: .normal)
        UIView.transition(with: card, duration: 0.3, options: [.transitionFlipFromRight], animations: nil, completion: nil)
    }
    
    func startDuratuonTimer()
    {
        durationTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(slowDown), userInfo: nil, repeats: true)
    }
    func resetDutrationTimer()
    {
        durationTimer.invalidate()
        flipAnimationDuration = 0.1
        stopFlip = false
        startDuratuonTimer()
        
    }
    func startCardDisplayTimer()
    {
         cardDisplayTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(countDown), userInfo: nil, repeats: true)
    }
    func stopCardDisplayTimer()
    {
        cardDisplayTimer.invalidate()
    }
    
    @objc func countDown()
    {
        if cardDisplayTime > 0
        {
            cardDisplayTime -= 1
            if cardDisplayTime <= 3
            {
                countNumLabel.text = String(cardDisplayTime)
            }
        }
        else
        {
            countNumLabel.text = ""
            cardDisplayTime = 7
            stopCardDisplayTimer()
            goNextPlayer()
        }
       
        
    }
    func flipOnce()
    {
        if allCardsDealed == false
        {
            nextPlayerBtn.isHidden = true
            card.setImage(image, for: .normal)
            UIView.transition(with: card, duration: flipAnimationDuration, options: [.transitionFlipFromLeft], animations: nil, completion:
                {(finished: Bool) in
                    self.flipTwice()})
        }
        else
        {
            dealingCardsFinished()
        }


    }
    func flipTwice()
    {
        if stopFlip == false
        {

            let randomIndex = arc4random() % UInt32(roleList.count)
            let named = roleList[Int(randomIndex)]
            let image = UIImage(named: named)
            card.setImage(image, for: .normal)
            
            
            UIView.transition(with: card, duration: flipAnimationDuration, options: [.transitionFlipFromLeft], animations: nil, completion: {(finished: Bool) in
                self.flipOnce()})
            
        }
        else
        {
            setRandomCard()
        }
        
    }
    func setRandomCard()
    {

        if dynamicRoleList.count >= 0
        {
            if dynamicRoleList.count == 1
            {
                allCardsDealed = true
                nextPlayerBtn.isHidden = true
            }
            else
            {
                nextPlayerBtn.isHidden = false
                startCardDisplayTimer()
            }
            
            let randomIndex = arc4random() % UInt32(dynamicRoleList.count)
            let named = dynamicRoleList[Int(randomIndex)]
            let image = UIImage(named: named)
            card.setImage(image, for: .normal)
            dynamicRoleList.remove(at: Int(randomIndex))
            UIView.transition(with: card, duration: flipAnimationDuration, options: [.transitionFlipFromLeft], animations: nil, completion:
                {(finished: Bool) in self.setDetails(named: named)
            })
        }
    }
    
    func dealingCardsFinished()
    {
        UIView.animate(withDuration: 0.5, delay: 0.2, options: .curveEaseOut, animations: {
            self.roleName.alpha = 0.0
        }, completion: nil)
        UIView.animate(withDuration: 0.5, delay: 0.4, options: .curveEaseOut, animations: {
            self.card.alpha = 0.0
        }, completion: nil)
        UIView.animate(withDuration: 0.5, delay: 0.6, options: .curveEaseOut, animations: {
            self.roleDetail.alpha = 0.0
        }, completion: nil)
        
    }
    
    @objc func slowDown()
    {
        flipAnimationDuration *= 1.8
        if flipAnimationDuration >= 0.6
        {
            stopFlip = true
        }
    }
    
    func setDetails(named: String)
    {
        self.roleName.text = named
        
        
        switch named
        {
            case "witch":
                roleDetail.text = "You have a bottle of poison, a bottle of antidote, you can choose to use it in the dark, but you can't use both drugs at the same time." //"你有一瓶毒药，一瓶解药，你可以在天黑的时候选择使用，但是不能同时使用两种药"
            case "villager"://"villagers":
                roleDetail.text = "You are an ordinary villager, you can’t blink at night." //"你是一个平凡的村民，在夜里全程不能睁眼"
            case "werewolf":
                roleDetail.text = "You are a werewolf, please confirm your companion at night and choose to kill an innocent victim." //"你是狼人，请在夜里确认自己的同伴，并且选择杀害一位无辜的受害者"
            case "seer":
                roleDetail.text = "You are a seer who can check the identity of a player at night." //"你是预言家，可以在夜里查验一名玩家的身份"
            case "savior":
                roleDetail.text = "You are a savior, you can protect a player from being killed at night."
            //"你是守卫，可以在夜里保护一名玩家不被杀害"
            default:
                print("Switch error")
        }
    }
    
    
    
}


