import XCTest
@testable import SQLiteTests

XCTMain([
testCase([
])])
